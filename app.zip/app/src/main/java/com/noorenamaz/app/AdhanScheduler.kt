package com.noorenamaz.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

object AdhanScheduler {
    private val zone = TimeZone.getTimeZone("Asia/Kolkata")

    fun scheduleDay(context: Context, times: PrayerTimes) {
        val prefs = context.getSharedPreferences("noor_settings", Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean("adhan_enabled", true)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val parser = SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = zone }
        val dateParser = SimpleDateFormat("dd-MM-yyyy", Locale.US).apply { timeZone = zone }
        val date = dateParser.parse(times.dateKey) ?: return
        val prayers = times.entries()

        prayers.forEach { (id, pair) ->
            val (name, time) = pair
            val parsedTime = parser.parse(time) ?: return@forEach
            val cal = Calendar.getInstance(zone).apply {
                time = date
                val clock = Calendar.getInstance(zone).apply { time = parsedTime }
                set(Calendar.HOUR_OF_DAY, clock.get(Calendar.HOUR_OF_DAY))
                set(Calendar.MINUTE, clock.get(Calendar.MINUTE))
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val trigger = cal.timeInMillis
            val intent = Intent(context, AdhanAlarmReceiver::class.java).apply {
                // PendingIntent identity includes the data URI; this keeps each
                // prayer on each calendar date distinct, even within one year.
                data = android.net.Uri.parse("noorenamaz://adhan/${times.dateKey}/$id")
                putExtra("prayer_name", name)
                putExtra("prayer_id", id)
                putExtra("date_key", times.dateKey)
            }
            val pending = PendingIntent.getBroadcast(
                context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            if (!enabled || trigger <= System.currentTimeMillis()) {
                alarmManager.cancel(pending)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                !alarmManager.canScheduleExactAlarms()
            ) {
                // Graceful fallback: Android may delay this inexact alarm.
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
            }
        }
    }

}
