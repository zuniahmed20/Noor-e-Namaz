package com.noorenamaz.app

import android.content.Context
import java.util.Calendar
import java.util.TimeZone
import java.util.concurrent.Executors

object PrayerAlarmCoordinator {
    private val executor = Executors.newSingleThreadExecutor()

    fun refresh(context: Context) {
        val appContext = context.applicationContext
        executor.execute {
            try {
                val today = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"))
                val tomorrow = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
                val todayTimes = PrayerTimeRepository.fetchKolkata(today)
                val tomorrowTimes = PrayerTimeRepository.fetchKolkata(tomorrow)
                AdhanScheduler.scheduleDay(appContext, todayTimes)
                AdhanScheduler.scheduleDay(appContext, tomorrowTimes)
                appContext.getSharedPreferences("noor_settings", Context.MODE_PRIVATE)
                    .edit().putString("last_schedule_date", todayTimes.dateKey).apply()
            } catch (e: Exception) {
                appContext.getSharedPreferences("noor_settings", Context.MODE_PRIVATE)
                    .edit().putString("last_schedule_error", e.message ?: "Unknown error").apply()
            }
        }
    }
}
