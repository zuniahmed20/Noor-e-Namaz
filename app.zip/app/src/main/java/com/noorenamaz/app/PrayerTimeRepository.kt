package com.noorenamaz.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

data class PrayerTimes(
    val dateKey: String,
    val fajr: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String
) {
    fun entries(): List<Pair<Int, Pair<String, String>>> = listOf(
        0 to ("फ़ज्र" to fajr),
        1 to ("ज़ुहर" to dhuhr),
        2 to ("असर" to asr),
        3 to ("मगरिब" to maghrib),
        4 to ("ईशा" to isha)
    )
}

/**
 * Uses AlAdhan's city timetable API. Defaults match the saved Kolkata prototype:
 * Kolkata, India; Karachi calculation method (method=1).
 * Confirm displayed times against the user's local mosque timetable.
 */
object PrayerTimeRepository {
    fun fetchKolkata(date: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"))): PrayerTimes {
        val dateParam = SimpleDateFormat("dd-MM-yyyy", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("Asia/Kolkata")
        }.format(date.time)
        val url = URL(
            "https://api.aladhan.com/v1/timingsByCity/$dateParam" +
                "?city=Kolkata&country=India&method=1"
        )
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 12000
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                .bufferedReader(Charsets.UTF_8).use { it.readText() }
            check(code in 200..299) { "Prayer-time server returned HTTP $code" }
            val root = JSONObject(body)
            check(root.optInt("code") == 200) { "Prayer-time data was unavailable" }
            val data = root.getJSONObject("data")
            val timings = data.getJSONObject("timings")
            val dateKey = data.getJSONObject("date").getJSONObject("gregorian").getString("date")
            fun clean(key: String) = timings.getString(key).substringBefore(" ").trim()
            return PrayerTimes(
                dateKey = dateKey,
                fajr = clean("Fajr"),
                dhuhr = clean("Dhuhr"),
                asr = clean("Asr"),
                maghrib = clean("Maghrib"),
                isha = clean("Isha")
            )
        } finally {
            connection.disconnect()
        }
    }
}
