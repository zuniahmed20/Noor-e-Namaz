package com.noorenamaz.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder

class AdhanPlaybackService : Service() {
    private var player: MediaPlayer? = null
    private val channelId = "noor_adhan"

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prayer = intent?.getStringExtra("prayer_name") ?: "Namaz"
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Noor-e-Namaz")
            .setContentText("$prayer का समय हो गया है")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .build()

        startForeground(1001, notification)

        // Add a permitted audio file as app/src/main/res/raw/adhan.mp3.
        val audioId = resources.getIdentifier("adhan", "raw", packageName)
        if (audioId == 0) {
            // No recording is bundled yet. Do not leave an empty foreground service running.
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
            return START_NOT_STICKY
        }

        player?.release()
        player = MediaPlayer.create(this, audioId)
        if (player == null) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
            return START_NOT_STICKY
        }
        player?.apply {
            setOnCompletionListener {
                it.release()
                player = null
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            setOnErrorListener { mediaPlayer, _, _ ->
                mediaPlayer.release()
                player = null
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                true
            }
            start()
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Adhan alerts", NotificationManager.IMPORTANCE_HIGH
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
