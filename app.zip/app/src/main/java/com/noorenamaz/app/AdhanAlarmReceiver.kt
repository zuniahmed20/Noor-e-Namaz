package com.noorenamaz.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AdhanAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prayerName = intent.getStringExtra("prayer_name") ?: "नमाज़"
        val serviceIntent = Intent(context, AdhanPlaybackService::class.java).apply {
            putExtra("prayer_name", prayerName)
        }
        ContextCompat.startForegroundService(context, serviceIntent)
        // Refresh the next two days so the following day's prayers remain scheduled.
        PrayerAlarmCoordinator.refresh(context)
    }
}
